# docker-ubuntu

## How to run the Ubuntu container

`docker-compose -f docker-compose.yml up -d`

## How to access the Ubuntu container terminal

`docker exec -it ubuntu bash`

## How to stop the Ubuntu container

`docker-compose -f docker-compose.yml down`
